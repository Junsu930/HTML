const img = document.getElementById("img");

img.addEventListener("mouseover", function(){
    document.getElementById("query").style.visibility="visible";
    document.getElementById("query").style.width = "400px";
})

