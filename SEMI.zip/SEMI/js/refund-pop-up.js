
function refundYes(){
    opener.document.getElementById("main-form").submit();
    window.close();
}

function refundNo(){
    window.close();
}